const myBtn = document.getElementById("myBtn");
const myLabel1 = document.getElementById("myLabel1");
const myLabel2 = document.getElementById("myLabel2");
const myLabel3 = document.getElementById("myLabel3");
const  max=6;
const min=1;
let ranNumber1;
let ranNumber2;
let ranNumber3;

myBtn.onclick = function (){
    ranNumber1= Math.floor(Math.random() * max) + min;
    myLabel1.textContent=ranNumber1;

    ranNumber2= Math.floor(Math.random() * max) + min;
    myLabel2.textContent=ranNumber2;

    ranNumber3= Math.floor(Math.random() * max) + min;
    myLabel3.textContent=ranNumber3;
}
